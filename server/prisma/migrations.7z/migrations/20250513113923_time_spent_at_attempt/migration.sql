-- AlterTable
ALTER TABLE "test_attempts" ADD COLUMN     "timeSpent" INTEGER NOT NULL DEFAULT 0;
