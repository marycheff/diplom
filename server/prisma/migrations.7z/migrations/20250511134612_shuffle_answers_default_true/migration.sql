-- AlterTable
ALTER TABLE "test_settings_snapshots" ALTER COLUMN "shuffleAnswers" SET DEFAULT true;
