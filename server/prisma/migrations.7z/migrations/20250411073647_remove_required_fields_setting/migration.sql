/*
  Warnings:

  - You are about to drop the column `requiredFields` on the `test_settings` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "test_settings" DROP COLUMN "requiredFields";
