-- AlterTable
ALTER TABLE "test_settings" ALTER COLUMN "shuffleAnswers" SET DEFAULT true;
