/*
  Warnings:

  - You are about to drop the column `totalAttempts` on the `tests` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "tests" DROP COLUMN "totalAttempts";
